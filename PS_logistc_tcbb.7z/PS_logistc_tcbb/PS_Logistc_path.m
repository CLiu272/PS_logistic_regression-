function [ beta_path,intercept_path,lambda_path] = PS_Logistc_path( X,y,m,lambda_path )
%PS_LOGISTC Summary of this function goes here
%   Detailed explanation goes here
[row,col] = size(X);
Weight = abs(corr(X)).^4;
for i = 1: col
    for j = 1: col
        if Weight(i,j) < 0.3 || isnan(Weight(i,j))==1
            Weight(i,j) = 0 ;
        end
    end
end

for i = 1 : col
    miu(i) = corr(y,X(:,i));
    if isnan(miu(i)) == 1 || (miu(i) == 0)
        miu(i) = 0.0001;
    end
end

miu1 = 1./(miu.^2);
alpha = 0.5;

temp = sum(y)/row;
beta_zero = log(temp/(1-temp));    %intercept
beta = zeros(col,1);

if nargin < 4
    
    %%%%%%%%%%%%%% compute lambda on the log scale %%%%%%%%%%%%%%%%%%%%%
    eta = beta_zero;   %%%%% eta= intercept + X*beta;
    Pi = exp(eta)./(1+exp(eta));
    W = diag(Pi.*(1-Pi));           %%%%%%%%% W is diagonal matrix%%%%%%%%%%
    r = (W^-1)*(y-Pi);            %residual= (w^-1)*(y-pi)
    S = (X'*W*r)/row;
    
    lambda_max = max(S/(alpha*min(miu1)));
    lambda_min = lambda_max*0.0005;
    
    for i = 1:m
        lambda_path(i) = lambda_max*(lambda_min/lambda_max)^(i/m);
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:m
    lambda = lambda_path(i);
    iter = 0;
    maxiter = 10;
    beta_path(:,i) = beta(:,1);
    intercept_path(i) = beta_zero;
    while iter < maxiter %true
        
        beta_temp = beta;
        beta_zero_temp = beta_zero;
        
        eta = beta_zero_temp + X*beta_temp;   %%%%% eta= intercept + X*beta;
        Pi = exp(eta)./(1+exp(eta));
        W = diag(Pi.*(1-Pi));           %%%%%%%%% W is diagonal matrix%%%%%%%%%%
        r = (W^-1)*(y-Pi);            %residual= (w^-1)*(y-pi)
        
        %%%%%%%%%%%%%%%%%%%% intercept%%%%%%%%%%%%%%%%%%%%%%
        beta_zero = sum(y-Pi)/sum(sum(W)); %+ beta_zero_temp;
        r = r - (beta_zero - beta_zero_temp);
        
        for j=1:col
            
            part1 = 0;
            part2 = 1;
            
            for k = 1:col
                part1 =  part1 + Weight(k,j)* miu(k)* miu(j)*(-beta(k));
                part2 =  part2 + Weight(k,j)* miu(j)* miu(j);
            end
            
            part1 =  part1 -  miu(j)* miu(j)*(-beta(j));
            part2 =  part2 -  miu(j)* miu(j);
            part1 =  part1 * (lambda * (1-alpha));
            part2 =  part2 * (lambda * (1-alpha))+1;
            
            S=(X(:,j)'*W*r)/row + beta_temp(j) + part1;
            
            if S > (lambda*alpha*miu1(j))
                beta(j) = (S - (lambda*alpha*miu1(j)))/part2;%/(1+lambda*(1-alpha));
            elseif S < -(lambda*alpha*miu1(j))
                beta(j) = (S + lambda*alpha*miu1(j))/part2;%/(1+lambda*(1-alpha));
            elseif abs(S) <= (lambda*alpha*miu1(j))
                beta(j) = 0;
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%--update r---%%%%%%%%%%%%%%%%%%%%%%%%%%
            r= r - X(:,j)*(beta(j)-beta_temp(j));
            
        end
        
        if norm(beta_temp - beta) < (1E-5)
            break;
        end
        
        iter = iter + 1;
        
    end
      
end


end

