function [ X_train,y_train,X_test,y_test ] = simulation_data_generate( tr_num,te_num,dimension )
%SIMULATION_DATA_GENERATE

beta = zeros(dimension,1);
beta(1) = 1;
beta(2) = 1;
beta(3) = 1;
beta(5) = -1;
beta(6) = -1;
beta(7) = -1;

actual_beta = beta;
sample_size = tr_num + te_num;
intercept = 0.7;

mu = zeros(1,dimension);
sigma = diag(ones(1,dimension));
sigma(1,2) = 0.95;
sigma(2,1) = 0.95;
sigma(1,3) = 0.95;
sigma(3,1) = 0.95;
sigma(2,3) = 0.95;
sigma(3,2) = 0.95;

sigma(5,6) = 0.95;
sigma(7,5) = 0.95;
sigma(6,7) = 0.95;
sigma(6,5) = 0.95;
sigma(5,7) = 0.95;
sigma(7,6) = 0.95;

X = mvnrnd(mu,sigma,sample_size);
X = standardizeCols(X);

eta = intercept+beta'*X';
prob = exp(eta)./(1 + exp(eta));

for i = 1:sample_size
    if prob(i)>0.5
        p_y(i) = 1;
    else
        p_y(i) = 0;
    end
end
y = p_y';


X_test = X(tr_num+1:end,:);
y_test = y(tr_num+1:end,:);

X_train = X(1:tr_num,:);
y_train = y(1:tr_num,:);

end

