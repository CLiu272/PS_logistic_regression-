function [ opt_index ] = CV_PSL( X,Y,fold,m,lambda_path)
%CV_PSL Summary of this function goes here
%   m is the number of lambda

for i = 1:fold
    
    sample_size = length(Y);
    te_idx = i : fold : sample_size;
    tr_idx = setdiff(1:sample_size, te_idx);
    
    cv_Xtr = X(tr_idx, :);
    cv_Ytr = Y(tr_idx, :);
    cv_Xte = X(te_idx, :);
    cv_Yte = Y(te_idx, :);
    
    [beta_path,intercept_path,~] = PS_Logistc_path(cv_Xtr, cv_Ytr,m,lambda_path);
    [Performmat(i,:),~] = Evalution_function(cv_Xte,cv_Yte,beta_path,intercept_path);
    
end


Performance_vector = sum(Performmat,1);

[~,opt_index] = max(Performance_vector);

%lambda_opt = lambda_path(opt_index);

end

