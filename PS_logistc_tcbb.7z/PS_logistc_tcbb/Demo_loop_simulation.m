clear
clc

addpath('./glmnet')
addpath('./Evaluation function')

%% the Package glmnet from  Jerome Friedman, Trevor Hastie and Rob Tibshirani. (2008). 
% Regularization Paths for Generalized Linear Models via Coordinate Descent 
% Journal of Statistical Software, Vol. 33(1), 1-22 Feb 2010
% http://web.stanford.edu/~hastie/glmnet_matlab/


fold = 5;  % cross-validation folds
m = 10;    % the number of tuning parameters( lambda )

tr_num = 120;
te_num = 100;
dimension = 2000;

maxIter = 30;
fprintf('  number of training samples =%d number of feature =%d number of iteration =%d CV=%d \n\n',te_num,dimension,maxIter,fold);

for iter = 1:maxIter
    
    [ X_train,Y_train,X_test,Y_test ] = simulation_data_generate( tr_num,te_num,dimension );
    
    %%%%%%%%%%%%%%%%%%%%%%%%% PS_Logisitc %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [ beta_path,intercept_path,lambda_path] = PS_Logistc_path( X_train,Y_train,m );
    [ opt_index ] = CV_PSL( X_train,Y_train,fold,m,lambda_path);
    [ PS_Performance(iter) ] = Evalution_function( X_test,Y_test,beta_path(:,opt_index),intercept_path(opt_index) );
    
    %%% True nonzero features
    Ps_nz_num(iter) = length(find(beta_path(:,opt_index)~=0));
    Ps_1(iter) = beta_path(1,opt_index)~=0;
    Ps_2(iter) = beta_path(2,opt_index)~=0;
    Ps_3(iter) = beta_path(3,opt_index)~=0;
    Ps_5(iter) = beta_path(5,opt_index)~=0;
    Ps_6(iter) = beta_path(6,opt_index)~=0;
    Ps_7(iter) = beta_path(7,opt_index)~=0;
   
    %%%%%%%%%%%%%%%%%%%%%%%%% EN_Logisitc %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    options = glmnetSet;
    options.alpha = 0.5;
    %options.nlambda = 10;
    
    fit=glmnet(X_train,Y_train + 1,'binomial',options);
    CVerr=cvglmnet(X_train,Y_train+1,fold,[],'class','binomial',glmnetSet,0);
    beta_path = fit.beta;
    intercept_path = fit.a0;
    lambda_path = fit.lambda;
    opt_index = find(CVerr.glmnetOptions.lambda == CVerr.lambda_min);
    [ EN_Performance(iter) ] = Evalution_function( X_test,Y_test,beta_path(:,opt_index),intercept_path(opt_index) );
    
    EN_nz_num(iter) = length(find(beta_path(:,opt_index)~=0));
    EN_1(iter) = beta_path(1,opt_index)~=0;
    EN_2(iter) = beta_path(2,opt_index)~=0;
    EN_3(iter) = beta_path(3,opt_index)~=0;
    EN_5(iter) = beta_path(5,opt_index)~=0;
    EN_6(iter) = beta_path(6,opt_index)~=0;
    EN_7(iter) = beta_path(7,opt_index)~=0;
    %%%%%%%%%%%%%%%%%%%%%%%%% Lasso_Logisitc %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    options = glmnetSet;
    options.alpha = 1;
    %options.nlambda = 10;
    
    fit=glmnet(X_train,Y_train + 1,'binomial',options);
    CVerr=cvglmnet(X_train,Y_train+1,fold,[],'class','binomial',glmnetSet,0);
    beta_path = fit.beta;
    intercept_path = fit.a0;
    lambda_path = fit.lambda;
    opt_index = find(CVerr.glmnetOptions.lambda == CVerr.lambda_min);
    [ Lasso_Performance(iter) ] = Evalution_function( X_test,Y_test,beta_path(:,opt_index),intercept_path(opt_index) );
    
    L1_nz_num(iter) = length(find(beta_path(:,opt_index)~=0));
    L1_1(iter) = beta_path(1,opt_index)~=0;
    L1_2(iter) = beta_path(2,opt_index)~=0;
    L1_3(iter) = beta_path(3,opt_index)~=0;
    L1_5(iter) = beta_path(5,opt_index)~=0;
    L1_6(iter) = beta_path(6,opt_index)~=0;
    L1_7(iter) = beta_path(7,opt_index)~=0;
    
    fprintf(' Current iteration = %d \n\n',iter);
    
end


Ps_recovery_rate = (mean(Ps_1) + mean(Ps_2) + mean(Ps_3) + mean(Ps_5) + mean(Ps_6) + mean(Ps_7))/mean(Ps_nz_num);

EN_recovery_rate = (mean(EN_1) + mean(EN_2) + mean(EN_3) + mean(EN_5) + mean(EN_6) + mean(EN_7))/mean(EN_nz_num);

L1_recovery_rate = (mean(L1_1) + mean(L1_2) + mean(L1_3) + mean(L1_5) + mean(L1_6) + mean(L1_7))/mean(L1_nz_num);

fprintf(' Penalized strutured logisitc regression: peformance(Youden Index)=%f recovery_rate=%f \n\n',mean(PS_Performance),Ps_recovery_rate);
fprintf(' Elasitic Net Penalized logisitc regression: peformance(Youden Index)=%f recovery_rate=%f \n\n',mean(EN_Performance),EN_recovery_rate);
fprintf(' Lasso Penalized logisitc regression: peformance(Youden Index)=%f recovery_rate=%f \n\n',mean(Lasso_Performance),L1_recovery_rate);




