clear
clc

addpath('./glmnet')
addpath('./Evaluation function')

%% the Package glmnet from  Jerome Friedman, Trevor Hastie and Rob Tibshirani. (2008). 
% Regularization Paths for Generalized Linear Models via Coordinate Descent 
% Journal of Statistical Software, Vol. 33(1), 1-22 Feb 2010
% http://web.stanford.edu/~hastie/glmnet_matlab/


fold = 5;  % cross-validation folds
m = 10;    % the number of tuning parameters( lambda )

tr_num = 100;
te_num = 100;
dimension = 2000;

[ X_train,Y_train,X_test,Y_test ] = simulation_data_generate( tr_num,te_num,dimension );
fprintf('   number of training samples =%d number of feature =%d CV=%d \n\n',te_num,dimension,fold);

%%%%%%%%%%%%%%%%%%%%%%%%% PS_Logisitc %%%%%%%%%%%%%%%%%%%%%%%%%%

[ beta_path,intercept_path,lambda_path] = PS_Logistc_path( X_train,Y_train,m );
[ opt_index ] = CV_PSL( X_train,Y_train,fold,m,lambda_path);
[ PS_Performance,~ ] = Evalution_function( X_test,Y_test,beta_path(:,opt_index),intercept_path(opt_index) );

fprintf('   Penalized strutured logisitc regression: peformance(Youden Index)=%f \n\n',PS_Performance);

%%%%%%%%%%%%%%%%%%%%%%%%% EN_Logisitc %%%%%%%%%%%%%%%%%%%%%%%%%%

options = glmnetSet;
options.alpha = 0.5;
%options.nlambda = 10;

fit=glmnet(X_train,Y_train + 1,'binomial',options);
CVerr=cvglmnet(X_train,Y_train+1,fold,[],'class','binomial',glmnetSet,0);
beta_path = fit.beta;
intercept_path = fit.a0;
lambda_path = fit.lambda;
opt_index = find(CVerr.glmnetOptions.lambda == CVerr.lambda_min);
[ EN_Performance,~ ] = Evalution_function( X_test,Y_test,beta_path(:,opt_index),intercept_path(opt_index) );

fprintf('   Elastic Net Penalized logisitc regression: peformance(Youden Index)=%f \n\n',EN_Performance);

%%%%%%%%%%%%%%%%%%%%%%%%% Lasso_Logisitc %%%%%%%%%%%%%%%%%%%%%%%%%%

options = glmnetSet;
options.alpha = 1;
%options.nlambda = 10;

fit=glmnet(X_train,Y_train + 1,'binomial',options);
CVerr=cvglmnet(X_train,Y_train+1,fold,[],'class','binomial',glmnetSet,0);
beta_path = fit.beta;
intercept_path = fit.a0;
lambda_path = fit.lambda;
opt_index = find(CVerr.glmnetOptions.lambda == CVerr.lambda_min);
[ Lasso_Performance,~ ] = Evalution_function( X_test,Y_test,beta_path(:,opt_index),intercept_path(opt_index) );

fprintf('   Lasso Penalized logisitc regression: peformance(Youden Index)=%f \n\n',Lasso_Performance);









