function [ YI ] = Youden_index( y_test,predict_y )

Tp = length(find(predict_y(predict_y == 1) == y_test(predict_y == 1)));
Ap = length(find(y_test == 1));
sensitivity = Tp/Ap;
Tf = length(find(predict_y(predict_y == 0) == y_test(predict_y == 0)));
Af = length(find(y_test == 0));
specificity = Tf/Af;
YI = sensitivity + specificity -1;

end

