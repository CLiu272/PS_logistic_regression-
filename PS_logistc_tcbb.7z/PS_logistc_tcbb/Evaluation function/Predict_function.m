function [ predict_y ] = Predict_function( beta,intercept,X_test)

predict_y = intercept + X_test * beta;
for i=1:size(X_test,1)
    if sign(predict_y(i)) == 1
        predict_y(i)=1;
    else
        predict_y(i)=0;
    end
end

end

