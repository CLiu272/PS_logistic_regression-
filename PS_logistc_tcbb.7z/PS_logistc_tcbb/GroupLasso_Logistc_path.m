function [ beta_path,intercept_path,lambda_path] = GroupLasso_Logistc_path( X,y,m,C,lambda_path )
%PS_LOGISTC Summary of this function goes here
%   Detailed explanation goes here
[row,col] = size(X);

temp = sum(y)/row;
beta_zero = log(temp/(1-temp));    %intercept
beta = zeros(col,1);

cluster_idx = kmeans(X',C);

cluster_idx(1:3) = 1;
cluster_idx(5:7) = 2;
cluster_idx(4) = 3;
cluster_idx(8:end) = 3;

if nargin < 5
    
    %%%%%%%%%%%%%% compute lambda on the log scale %%%%%%%%%%%%%%%%%%%%%
    eta = beta_zero;   %%%%% eta= intercept + X*beta;
    Pi = exp(eta)./(1+exp(eta));
    %W = diag(Pi.*(1-Pi));           %%%%%%%%% W is diagonal matrix%%%%%%%%%%
    W = 0.25;
    r = (W^-1)*(y-Pi);            %residual= (w^-1)*(y-pi)
    S = (X'*W*r)/row;
    
    lambda_max = max(S);
    lambda_min = lambda_max*0.0005;
    
    for i = 1:m
        lambda_path(i) = lambda_max*(lambda_min/lambda_max)^(i/m);
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:m
    lambda = lambda_path(i);
    iter = 0;
    maxiter = 10;
    beta_path(:,i) = beta(:,1);
    intercept_path(i) = beta_zero;
    while iter < maxiter %true
        
        beta_temp = beta;
        beta_zero_temp = beta_zero;
        
        eta = beta_zero_temp + X*beta_temp;   %%%%% eta= intercept + X*beta;
        Pi = exp(eta)./(1+exp(eta));
        Pi(eta > 10) = 1;
        Pi(eta < -10) = 0;
        %W = diag(Pi.*(1-Pi));           %%%%%%%%% W is diagonal matrix%%%%%%%%%%
        W = 0.25;
        r = (W^-1)*(y-Pi);            %residual= (w^-1)*(y-pi)
        
        %%%%%%%%%%%%%%%%%%%% intercept%%%%%%%%%%%%%%%%%%%%%%
        %beta_zero = sum(y-Pi)/sum(sum(W)); %+ beta_zero_temp;
        beta_zero = sum(r)/row + beta_zero_temp;
        r = r - (beta_zero - beta_zero_temp);
                
        for c = 1:C
            
            idx = find(cluster_idx == c);
            
            S=(X(:,idx)'*W*r)/row + beta_temp(idx);
            S_norm = 1-(lambda*sqrt(length(idx))/norm(S));
            
            if S_norm < 0
                beta(idx) = 0;
            else
                beta(idx) = S_norm * S;
            end
            
            r= r - X(:,idx)*(beta(idx) - beta_temp(idx));
                     
        end
                
        if norm(beta_temp - beta) < (1E-5)
            break;
        end
        
        iter = iter + 1;
        
    end
      
end


end

